create
    definer = root@localhost procedure update_stock(IN menge int, IN f_id int, IN p_id int)
begin
    IF EXISTS(select * from PF where f_f_id = f_id and p_id = f_p_id) THEN
        update pf set pf_menge = pf_menge + menge where f_f_id = f_id and p_id = f_p_id;
    ELSE
        insert into PF(pf_menge, f_f_id, f_p_id) values (menge, f_id,p_id);
    end if;
end;

