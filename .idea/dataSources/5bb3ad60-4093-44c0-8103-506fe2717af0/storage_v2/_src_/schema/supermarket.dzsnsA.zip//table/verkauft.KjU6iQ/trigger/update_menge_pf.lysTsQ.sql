create definer = root@localhost trigger update_menge_pf
    after insert
    on verkauft
    for each row
begin
    SET @menge = New.v_menge;
    SET @id = NEW.f_p_id;
    update pf set pf_menge = pf_menge - @menge where f_p_id = @id;
end;

