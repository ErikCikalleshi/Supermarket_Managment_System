create
    definer = root@localhost procedure insert_sales(IN menge int, IN f_id int, IN p_id int, IN k_id int)
begin
    IF EXISTS(select * from PF where f_f_id = f_id and p_id = f_p_id and pf_menge >= menge) THEN
        insert into Verkauft(v_tag, v_menge, f_k_id, f_p_id, f_f_id) VALUES (now(), menge, k_id, p_id, f_id);
    ELSE
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'The Product doesn`t exist';
    end if;
end;

