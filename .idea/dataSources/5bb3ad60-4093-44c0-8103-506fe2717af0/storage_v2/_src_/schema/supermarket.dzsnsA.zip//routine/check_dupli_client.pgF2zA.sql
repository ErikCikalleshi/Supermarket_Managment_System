create
    definer = root@localhost procedure check_dupli_client(IN vorname varchar(40), IN nachname varchar(40),
                                                          IN email varchar(40), IN payer_id int)
begin
    IF NOT EXISTS(select * from Kunde where k_email = email and k_payer_id = payer_id) THEN
        insert into Kunde(k_vorname, k_nachname, k_email, k_payer_id) VALUES ( vorname, nachname, email, payer_id);
    end if;
end;

