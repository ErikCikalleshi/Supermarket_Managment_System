create
    definer = root@localhost procedure check_dupli_addr(IN plz int, IN adresse varchar(40), IN country_code varchar(5),
                                                        IN city varchar(40))
begin
    IF NOT EXISTS(select * from Lieferadresse where kl_plz = plz and adresse = kl_adresse) THEN
        insert into Lieferadresse(kl_country_code, kl_plz, kl_stadt, kl_adresse) VALUES (country_code, plz, city, adresse);
    end if;
end;

