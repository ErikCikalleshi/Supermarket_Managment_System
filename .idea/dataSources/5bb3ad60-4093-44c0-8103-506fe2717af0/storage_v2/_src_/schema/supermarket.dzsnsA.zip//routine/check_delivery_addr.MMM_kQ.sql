create
    definer = root@localhost procedure check_delivery_addr(IN email varchar(40), IN adresse varchar(40), IN plz int)
begin
    IF NOT EXISTS(select * from kunde_adresse where f_kl_id = (select kl_id from Lieferadresse where kl_plz = plz and kl_adresse = adresse) and f_k_id = (select k_id from kunde where k_email = email)) THEN
        insert into kunde_adresse(f_k_id, f_kl_id) VALUES ((select k_id from Kunde where k_email = email), (select kl_id from Lieferadresse where kl_plz = plz and kl_adresse = adresse));
    end if;
end;

